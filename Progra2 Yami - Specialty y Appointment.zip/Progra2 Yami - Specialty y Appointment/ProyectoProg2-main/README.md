--- Proyecto Colaborativo de API Clínica ---

Florencia Silvero - 35604 - florencia.silvero@uap.edu.ar

Yamila Caviglione - 37098 - yamila.caviglione@uap.edu.ar 

Agustin Beade - 37571 - agustin.beade@uap.edu.ar
